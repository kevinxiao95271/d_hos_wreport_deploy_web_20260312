import{r as t}from"./request-233ae5e9.js";const r=()=>t.get("/wr/dict/types"),c=e=>t.get(`/wr/dict/items/${e}`);export{c as a,r as g};
