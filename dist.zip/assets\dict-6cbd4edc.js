import{r as t}from"./request-284ad19c.js";const r=()=>t.get("/wr/dict/types"),c=e=>t.get(`/wr/dict/items/${e}`);export{c as a,r as g};
