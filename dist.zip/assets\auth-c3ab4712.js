import{r as s}from"./request-284ad19c.js";const r=t=>s.post("/api/auth/login",t),e=()=>s.get("/wr/org/list");export{e as g,r as l};
