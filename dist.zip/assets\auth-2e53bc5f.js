import{r as s}from"./request-233ae5e9.js";const r=t=>s.post("/api/auth/login",t),e=()=>s.get("/wr/org/list");export{e as g,r as l};
